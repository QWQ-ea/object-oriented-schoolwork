//p.196 ��ϰ 6��
//	2.�����⣺(10)
#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int cmpI(const void *a,const void *b){
	return (*(int*)a > *(int*)b) ? 1:
			(*(int*)a < *(int*)b) ? -1:0;
}
int cmpD(const void *a,const void *b){
	return (*(double*)a > *(double*)b) ? 1:
			(*(double*)a < *(double*)b) ? -1:0;
}
int cmpStr(const void *a,const void *b){
	int len1=strlen((char*)a);
	int len2=strlen((char*)b);
	if(len1==len2)
		return strcmp((char*)a,(char*)b);
	return len1-len2;
}
template <typename T> void display(T *a,int n){
	for(int i=0;i<n-1;i++)
		cout<<a[i]<<", ";
	cout<<a[n-1]<<endl;
}
int main(){
	int numI[10]={12,32,42,51,8,16,51,21,19,9};
	double numD[10]={32.1,456.87,332.67,442.0,98.12,451.79,340.12,54.55,99.87,72.5};
	char str[10][10]={"enter", "number", "size", "begin", "of","cat", "case", "program", "centain", "a"};
	display(numI,10);
	qsort((void *)numI,10,4,cmpI);
	display(numI,10);
	cout<<endl;
	
	display(numD,10);
	qsort((void *)numD,10,8,cmpD);
	display(numD,10);
	cout<<endl;
	
	display(str,10);
	qsort((void *)str,10,10,cmpStr);
	display(str,10);
	return 0;
}
