//p.235 ��ϰ 8��
//  2.�����⣺(3)
#include<cstdio>
#include<iostream>
#include "node.h"
using namespace std;

template <typename T> void reverseNode(node<T> *&head){
	if(head==NULL) return;
	node<T> *p,*tmp;
	tmp=head->next;
	head->next=NULL;
	while(tmp){
		p=tmp;
		tmp=tmp->next;
		p->next=head;
		head=p;
	}
}
int main(){
	int list[10]={1,2,3,4,5,6,7,8,9,10};
	node<int> *head=NULL;
	createList(head,list,10);
	show(head);
	reverseNode(head);
	show(head);
	return 0;
}
