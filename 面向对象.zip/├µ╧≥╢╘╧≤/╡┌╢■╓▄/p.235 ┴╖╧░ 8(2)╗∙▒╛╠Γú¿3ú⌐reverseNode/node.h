#ifndef node_H
#define node_H

#include<iostream>
#include "node.h"
using namespace std;

template <typename T> struct node{
	T element;
	node<T> *next;
};
/*
template <typename T> void createList(node<T> *head,const T *eleList,int n);
template <typename T> void show(node<T> *head);
template <typename T> void freeList(node<T> *head);
*/
template <typename T> void createList(node<T> *&head,const T *eleList,int n){
	node<T> *p;
	if(head!=NULL) freeList(head);
	for(int i=n-1;i>=0;i--){
		p=new node<T>;
		p->element=eleList[i];
		p->next=head;
		head=p;
	}
}
template <typename T> void show(node<T> *head){
	cout<<"list";
	for(;head;head=head->next)
		cout<<"->"<<head->element;
	cout<<endl;
}
template <typename T> void freeList(node<T> *&head){
	node<T> *p;
	while(head){
		p=head;
		head=head->next; 
		delete p;
	}
}
#endif
