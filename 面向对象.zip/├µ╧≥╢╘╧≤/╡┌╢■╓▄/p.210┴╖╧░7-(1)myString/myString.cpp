#include<iostream>
#include "myString.h"
int myString::StrLen(const char *str){
	int len=0;
	for(;*str++;len++);
	return len;
}
char *myString::StrCpy(char *dest,const char *source){
	char *tmp=dest;
	while(*source){
		*dest=*source;
		dest++,source++;
	}
	return tmp;
}
char *myString::StrNCpy(char *dest,const char *source,int size){
	char *tmp=dest;
	int cnt=0;
	while((*source)&&cnt<size){
		*dest=*source;
		dest++,source++;
		cnt++;
	}
	*dest='\0';
	return tmp;
}
char *myString::StrCat(char *dest,const char *str){
	char *tmp=dest;
	while(*dest) dest++;
	while(*str){
		*dest=*str;
		dest++,str++;
	}
	return tmp;
}
char *myString::StrUpr(char *str){
	char *tmp=str;
	while(*str++){
		if(*str>='a'&&*str<='z')
			*str=*str-32;
	}
	return tmp;
}
int myString::StrCmp(const char *str1,const char *str2){
	while(*str1&&*str2&&*str1==*str2)
			str1++,str2++;
	if(*str1>*str2) return 1;
	else if(*str1==*str2) return 0;
	else return -1;
}
