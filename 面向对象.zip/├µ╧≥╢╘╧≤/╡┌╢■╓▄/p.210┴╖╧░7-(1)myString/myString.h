#ifndef myString_H
#define myString_H
namespace  myString{
	int StrLen(const char*str);
	char *StrCpy(char *dest,const char *source);
	char *StrNCpy(char *dest,const char *source,int size);
	char *StrCat(char *dest,const char *str);
	char *StrUpr(char *str);
	int StrCmp(const char *str1,const char *str2);
}
#endif

