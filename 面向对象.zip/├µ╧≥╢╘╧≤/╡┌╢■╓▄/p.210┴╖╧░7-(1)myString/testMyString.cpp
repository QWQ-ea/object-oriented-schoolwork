//p.210 ��ϰ 7�� (1)#include<iostream>
#include "myString.h"
using namespace std;
using namespace myString;
int main(){
	char str1[50]="ShanghaiUniversity";
	char str2[50];
	cout<<str1<<endl;
	cout<<myString::StrLen(str1)<<endl;
	
	myString::StrCpy(str2,str1);
	cout<<"str2:   "<<str2<<endl;
	
	myString::StrNCpy(str2,str1,2);
	cout<<"str2:   "<<str2<<endl;
	
	myString::StrCat(str1,str2);
	cout<<"new str1:   "<<str1<<endl;
	
	myString::StrUpr(str1);
	cout<<"new str1:   "<<str1<<endl;
	
	cout<<myString::StrCmp("aaa","bbb")<<endl;
	cout<<myString::StrCmp("bbb","aaa")<<endl;
	cout<<myString::StrCmp("aaa","aaa")<<endl;
	return 0;
}
