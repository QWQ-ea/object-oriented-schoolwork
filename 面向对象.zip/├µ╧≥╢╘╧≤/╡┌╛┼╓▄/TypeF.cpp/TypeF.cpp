#include<iostream>
#include<iomanip>
#include<sstream>
#include<conio.h>
#include"TypeF.h"
using namespace std;
TypeF::TypeF(char *filename)
{
buf=NULL;
if(filename==NULL) {fname="noname";size=0;}
else if(filename[0]=='?') {fname="命令本身为第0个参数";size=0;}
else open(filename);
}
TypeF::TypeF(const TypeF &a)
{
buf=NULL;fname=a.fname;size=a.size;
if(size>0) {buf=new unsigned char[size];for(int i=0;i<size;i++) buf[i]=a.buf[i];}
}
TypeF & TypeF::operator=(const TypeF &a)
{
if(&a==this) return *this;
if(buf!=NULL) delete [] buf;
buf=NULL;fname=a.fname;size=a.size;
if(size>0) {buf=new unsigned char[size];for(int i=0;i<size;i++) buf[i]=a.buf[i];}
return *this;
}
TypeF::~TypeF()
{
	if(buf!=NULL) delete [] buf;
}
void TypeF::open(char *filename)
{
	if(buf!=NULL) delete [] buf;
    buf=NULL;
	ifstream infile(filename,ios::binary);
	if(infile.fail()) return;
	size=filesize(infile);
	buf=new unsigned char[size];
	infile.read((char*)buf,size);
	infile.close();
	fname=filename;
}
int TypeF::isprint(unsigned char c)
{
	c&=127;
	return (int)c>=0&&(int)c<127;
}
int TypeF::filesize(ifstream &infile)
{
int cur_pos=infile.tellg();
infile.seekg(0,ios::end);
int size=infile.tellg();
infile.seekg(cur_pos,ios::beg);
return size;
}
void TypeF::show(int a)
{
if(size==0) return;
if(a==0) a=size;
if(a>0)
{ int i=0;
	while(i<a){
	if(isprint(buf[i])==0) cout<<".";
	else cout<<buf[i];
    i++;
}
	return;
}
if(a<0)
{int i=size-1;
a=size+a;
while(i>=a)
{
	if(isprint(buf[i])==0) cout<<".";
	else cout<<buf[i];
	i--;
}
return;
}
}


