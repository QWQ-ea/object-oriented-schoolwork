#include<iostream>
#include"TypeF.h"
#include<conio.h>
using namespace std;
int fsize(char *filename)
{
	int len;
	ifstream file(filename, ios::binary);
	file.seekg(0, ios::end);
	len = file.tellg();
	file.close();
	return len;
}
int main(int argc,char *argv[])
{
if(argc==1||argv[1][0]=='?') {cout<<"命令本身为第0个参数"<<endl<<"第二个参数不能为空"<<endl;return 0;}	
int n=(argc>2)?atoi(argv[2]):fsize(argv[1]);
TypeF a(argv[1]);
a.show(n);
	return 0;
}
