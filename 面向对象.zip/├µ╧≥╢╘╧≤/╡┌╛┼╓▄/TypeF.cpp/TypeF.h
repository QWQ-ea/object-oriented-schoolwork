#ifndef TYPEF_H
#define TYPEF_H
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
class TypeF
{
public:	
TypeF(char *filename);
TypeF(const TypeF &a);
TypeF & operator=(const TypeF &a);
virtual ~TypeF();
void open(char *filename);
void show(int a);
protected:
int isprint(unsigned char c);
int filesize(ifstream &infile);
private:
unsigned char *buf;
int size;
string fname;
};
#endif
