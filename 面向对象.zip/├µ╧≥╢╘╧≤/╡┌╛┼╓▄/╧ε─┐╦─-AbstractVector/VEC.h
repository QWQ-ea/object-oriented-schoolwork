//VEC.h
#ifndef VEC_H
#define VEC_H
#include <iostream>
using namespace std;
template <typename T> class VECTOR{
public:
	VECTOR(int size=0, const T *x=NULL) throw(bad_alloc){
		num = (size>0) ? size : 0;
		p = NULL;
		if(num>0){
			p = new T[num];
			for(int i=0; i<num; i++)
				p[i] = (x==NULL)? 0 : x[i];
		}
	}
	VECTOR(const VECTOR &v){
		num = v.num;
		p = NULL;
		if(num>0){
			p = new T[num];
			for(int i=0; i<num; i++)
				p[i] = v.p[i];
		}
	}
	virtual ~VECTOR(){
		if(p!=NULL) delete [] p;
	}
	VECTOR & operator=(const VECTOR &v) throw(bad_alloc){
		if(num!=v.num){
			if(p!=NULL) delete [] p;
			p = new T[num=v.num];
		}
		for(int i=0; i<num; i++)
			p[i] = v.p[i];
		return *this;
	}
	T & operator[](int index) const throw(char){
		if(index>num-1)
			throw 'a';
		return p[index];
	}
	int getsize() const{
		return num;
	}
	void resize(int size) throw(bad_alloc){
		if(size<0 || size==num) return;
		else if(size==0){
			if(p!=NULL) delete [] p;
			num = 0;
			p = NULL;
		}
		else{
			T *temp = p;
			p = new T[size];
			for(int i=0; i<size; i++)
				p[i] = (i<num) ? temp[i] : 0;
			num = size;
			delete [] temp;	
		}
	}
	virtual void Output(ostream &out) const = 0;
	virtual void Input(istream &in) = 0;

protected:
	int num;
	T *p;
};
template <typename T> ostream & operator<<(ostream &out, const VECTOR<T> &v){
	v.Output(out);
	return out;
}
template <typename T> istream & operator>>(istream &in, VECTOR<T> &v){
	v.Input(in);
	return in;
}

#endif
