//String.h
#ifndef STRING_H
#define STRING_H
#include "VEC.h"
#include<cstring>
class String : public VECTOR<char>{
public:
	String(const char *str="") throw(bad_alloc);
	int length() const;
	void Output(ostream &out) const;
	void Input(istream &in) throw(bad_alloc,char);
	friend istream &getline(istream &in,String &str,int n,char ch='\n') throw(bad_alloc,char);
	friend String operator+(const String &s1,const String &s2) throw(bad_alloc);
	String & operator+=(const String &str) throw(bad_alloc);
	friend bool operator< (const String &s1, const String &s2) throw(double);
	friend bool operator<=(const String &s1, const String &s2) throw(double);
	friend bool operator> (const String &s1, const String &s2) throw(double);
	friend bool operator>=(const String &s1, const String &s2) throw(double);
	friend bool operator==(const String &s1, const String &s2) throw(double);
	friend bool operator!=(const String &s1, const String &s2) throw(double);
};
//���캯�� 
String::String(const char *str) throw(bad_alloc) : VECTOR<char>(strlen(str),str){
}
//�����ַ�������
int String::length() const{
	return num;
}
void String::Output(ostream &out) const{
	for(int i=0;i<num;i++)
		out<<p[i];
}
//���뺯�� 
void String::Input(istream &in) throw(bad_alloc,char){
	String tmp;
	tmp.resize(10000);
	int len=0;
	char ch;
	char str[10000];
	//������Ч�ַ� 
	in.getline(str,1,'\n');
	in.getline(str,10000,'\n');
	int len1=strlen(str);
	for(int i=0;i<len1;i++){
		ch=tmp[len];
		if(ch==' '||ch=='\n'||ch=='\t')
			continue;
		else{
			tmp[len]=str[i];
			len++;
		}
	}
	tmp.resize(len);
	*this=tmp;
}
istream &getline(istream &in,String &str,int n,char ch) throw(bad_alloc,char){
	if(n<=0) return in;
	char s[n];
	in.getline(s,n,ch);
	str=s;
	return in;
}
String operator+(const String &s1,const String &s2) throw(bad_alloc){
	String tmp(s1);
	int len=s1.length()+s2.length();
	tmp.resize(len);
	for(int i=s1.length(),j=0;i<len;i++,j++)
		tmp[i]=s2[j];
	return tmp;
}
String & String::operator+=(const String &str) throw(bad_alloc){
	resize(num+str.length());
	*this=*this+str;
	return *this;
}
bool operator< (const String &s1, const String &s2) throw(double){
	int len1=s1.length(),len2=s2.length();
	if(len1==0||len2==0)
		throw 4.0;
	int cnt=0;
	while(s1[cnt]==s2[cnt]&&cnt<len1&&cnt<len2)
		cnt++;
	if(cnt<len1&&cnt==len2) return false;
	else if(cnt==len1&&cnt<len2) return true;
	else if(s1[cnt]<s2[cnt]) return true;
	else return false;
}
bool operator<=(const String &s1, const String &s2) throw(double){
	int len1=s1.length(),len2=s2.length();
	if(len1==0||len2==0)
		throw 4.0;
	int cnt=0;
	while(s1[cnt]==s2[cnt]&&cnt<len1&&cnt<len2)
		cnt++;
	if(cnt<=len1&&cnt<len2) return s1[cnt]<s2[cnt];
	if(cnt<len1&&cnt==len2) return false;
	else return true;
}
bool operator> (const String &s1, const String &s2) throw(double){
	return !(s1<=s2);
}
bool operator>=(const String &s1, const String &s2) throw(double){
	return !(s1<s2);
}
bool operator==(const String &s1, const String &s2) throw(double){
	int len1=s1.length(),len2=s2.length();
	if(len1==0||len2==0)
		throw 4.0;
	int cnt=0;
	while(s1[cnt]==s2[cnt]&&cnt<len1&&cnt<len2)
		cnt++;
	if(cnt<len1||cnt<len2) return false;
	else return true;
}
bool operator!=(const String &s1, const String &s2) throw(double){
	return !(s1==s2);
}
#endif
