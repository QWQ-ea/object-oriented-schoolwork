#ifndef VECTOR_H
#define VECTOR_H
#include "VEC.h"
#include<cstring>
template <typename T>
class Vector : public VECTOR<T>{
public:	
	Vector<T>(int size=0,const T *data=NULL) throw(bad_alloc) : VECTOR<T>(size,data){}
	template <typename TYPE> friend Vector<TYPE> operator+(const Vector<TYPE> &v1, const Vector<TYPE> &v2) throw(int,bad_alloc);
	template <typename TYPE> friend Vector<TYPE> operator-(const Vector<TYPE> &v1, const Vector<TYPE> &v2) throw(int,bad_alloc);
	template <typename TYPE> friend Vector<TYPE> operator*(const TYPE &x, const Vector<TYPE> &v) throw(bad_alloc);
	template <typename TYPE> friend Vector<TYPE> operator*(const Vector<TYPE> &v, const TYPE &x) throw(bad_alloc);
	Vector<T> & operator+=(const Vector<T> &v) throw(int,bad_alloc);
	Vector<T> & operator-=(const Vector<T> &v) throw(int,bad_alloc);
	Vector<T> & operator*=(const T &x) throw(int);
	void Input(istream &in) throw(bad_alloc);
	void Output(ostream &out) const;
};
//���� + 
template <typename TYPE>
Vector<TYPE> operator+(const Vector<TYPE> &v1, const Vector<TYPE> &v2) throw(int,bad_alloc){
	//����ά����ͬ������� 
	if(v1.getsize()!=v2.getsize())
		throw 1;
	Vector<TYPE> tmp(v1);
	for(int i=0;i<v1.getsize();i++)
		tmp[i]+=v2[i];
	return tmp;
}
//���� - 
template <typename TYPE>
Vector<TYPE> operator-(const Vector<TYPE> &v1, const Vector<TYPE> &v2) throw(int,bad_alloc){
	//����ά����ͬ������� 
	if(v1.getsize()!=v2.getsize())
		throw 1;
	Vector<TYPE> tmp(v1);
	for(int i=0;i<v2.getsize();i++)
		tmp[i]-=v2[i];
	return tmp;
}
//���� * 
template <typename TYPE>
Vector<TYPE> operator*(const TYPE &x, const Vector<TYPE> &v) throw(bad_alloc){
	Vector<TYPE> tmp(v);
	for(int i=0;i<v.getsize();i++)
		tmp[i]*=x;
	return tmp;
}
//���� * 
template <typename TYPE>
Vector<TYPE> operator*(const Vector<TYPE> &v, const TYPE &x) throw(bad_alloc){
	Vector<TYPE> tmp(v);
	for(int i=0;i<v.getsize();i++)
		tmp[i]*=x;
	return tmp;
}
//���� += 
template <typename T>
Vector<T> & Vector<T>::operator+=(const Vector<T> &v) throw(int,bad_alloc){
	*this=*this+v;
	return *this;
}
//���� -= 
template <typename T>
Vector<T> & Vector<T>::operator-=(const Vector<T> &v) throw(int,bad_alloc){
	*this=*this-v;
	return *this;
}
//���� *= 
template <typename T>
Vector<T> & Vector<T>::operator*=(const T &x) throw(int){
	*this=x* (*this);
	return *this;
}
//���뺯�� 
template <typename T>
void Vector<T>::Input(istream &in) throw(bad_alloc){
	char ch;
	Vector<T> tmp;
	tmp.resize(1000);
	int cnt=0;
	T buffer;
	//������Ч�ַ� 
	in>>ch;
	while(ch!='(')
		in>>ch;
	// ����һ���ַ�Ϊ')',��Ϊ0ά������ 
	if(in.peek()==')'){
		this->resize(0);
		return;
	}
	while(1){
		if(ch==')')
			break;
		in>>buffer>>ch;
		tmp[cnt]=buffer;
		cnt++;
	}
	tmp.resize(cnt);
	*this = tmp;
}
//�������
template <typename T>
void Vector<T>::Output(ostream &out) const{
	if(this->num==0)
		out<<"()";
	else{
		out<<"("<<this->p[0];
		for(int i=1;i<this->num;i++)
			out<<','<<this->p[i];
		out<<")";
	}
} 
#endif
