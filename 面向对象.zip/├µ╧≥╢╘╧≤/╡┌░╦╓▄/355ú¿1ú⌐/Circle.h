#ifndef CIRCLE_H
#define CIRCLE_H
#include"point.h"
class circle:public point
{
private:
double r;
public:
circle(double a=0,double b=0,double c=0);
circle(double c=0);
void Set(double c);
double Getr() const;
double zhouchang();
double mianji();
};
#endif
