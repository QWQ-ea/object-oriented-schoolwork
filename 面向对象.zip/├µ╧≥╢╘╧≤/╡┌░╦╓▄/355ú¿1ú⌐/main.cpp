#include<iostream>
#include"point.h"
#include"Circle.h"
#include"Cylinder.h"
using namespace std;
void Test()
{
	point a(1,2);
	double x=a.mochang();
	cout<<x<<endl;
	circle b(1,2,3);
	double y=b.zhouchang(),z=b.mianji();
	cout<<y<<","<<z<<endl;
	cylinder c(1,2,3,4);
	double m=c.biaomianji(),n=c.tiji();
	cout<<m<<","<<n<<endl;
}
int main()
{
	Test();
	return 0;
}
