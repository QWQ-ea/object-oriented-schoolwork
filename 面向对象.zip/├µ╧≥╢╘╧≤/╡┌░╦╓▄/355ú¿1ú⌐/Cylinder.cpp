#include<iostream>
#include"Cylinder.h"
#define pi 3.1415926
using namespace std;
cylinder::cylinder(double a,double b,double c,double d):circle(a,b,c),h(d){}
void cylinder::Set(double d)
{
	h=d;
}
double cylinder::Geth() const
{
	return h;
}
double cylinder::biaomianji()
{
	double area=0;
	area+=2*pi*Getr()*Getr()+pi*2*Getr()*h;
	return area;
}
double cylinder::tiji()
{
	double v=0;
	v+=pi*Getr()*Getr()*h;
	return v;
}
