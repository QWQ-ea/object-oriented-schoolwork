#ifndef CYLINDER_H
#define CYLINDER_H
#include"Circle.h"
class cylinder:public circle
{
private:
double h;
public:
cylinder(double a=0,double b=0,double c=0,double d=0);
void Set(double d);
double Geth() const;
double biaomianji();
double tiji();
};
#endif
