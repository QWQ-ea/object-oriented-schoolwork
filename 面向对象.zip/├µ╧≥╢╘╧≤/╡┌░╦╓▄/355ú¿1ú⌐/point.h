#ifndef POINT_H
#define POINT_H
class point
{
private:
double x,y;
public:
point(double a=0,double b=0);
void Set(double a,double b);
double mochang();
double Getx() const;
double Gety() const;
};
#endif
