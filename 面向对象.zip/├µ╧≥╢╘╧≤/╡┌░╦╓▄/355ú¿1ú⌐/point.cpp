#include<iostream>
#include"point.h"
#include<cmath>
using namespace std;
point::point(double a,double b):x(a),y(b){}
void point::Set(double a,double b)
{
	x=a;
	y=b;
}
double point::Getx() const
{
	return x;
}
double point::Gety() const
{
	return y;
}
double point::mochang()
{
double ans=0;
ans+=x*x+y*y;
return sqrt(ans);
}
