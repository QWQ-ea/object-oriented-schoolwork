#include<iostream>
#include"Circle.h"
#define pi 3.1415926
circle::circle(double a,double b,double c):point(a,b),r(c){}
circle::circle(double c):r(c){}
void circle::Set(double c)
{
	r=c;
}
double circle::Getr() const
{
	return r;
}
double circle::zhouchang()
{
return pi*2*r;	
}
double circle::mianji()
{
	return pi*r*r;
}
