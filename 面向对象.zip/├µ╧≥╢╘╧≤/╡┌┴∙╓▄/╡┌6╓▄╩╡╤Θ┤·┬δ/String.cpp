#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include "String.h"

String::String(const char *s) throw(bad_alloc){
	str=new char[strlen(s)+1];
	strcpy(str,s);
}
String::String(const String &s) throw(bad_alloc){
	str=new char[strlen(s.str)+1];
	strcpy(str,s.str);
}
String::~String(){
	if(str!=NULL)
		delete [] str;
}
String & String::operator=(const String &s) throw(bad_alloc){
	if(&s==this) return *this;
	delete [] str;
	str=new char[strlen(s.str)+1];
	strcpy(str,s.str);
	return *this;
}
int String::length() const{
	return strlen(str);
}
const char * String::c_str(){
	return str;
}
//����I/O����������� 
ostream & operator<<(ostream &out,const String &s){
	out<<s.str;
	return out;
}
istream & operator >>(istream &in,String &s) throw(bad_alloc){
	vector<char> vStr;
	char ch;
	while((ch=getchar())!='\n'){
		vStr.push_back(ch);
	}
	int len=vStr.size();
	if(s.str!=NULL) delete s.str;
	s.str=new char[len+1];
	for(int i=0;i<len;i++)
		s.str[i]=vStr[i];
	s.str[len]='\0';
	return in;
}
//����+��+=�����
String operator+(const String &s1,const String s2) throw(bad_alloc){
	String tmp;
	tmp.str=new char[strlen(s1.str)+strlen(s2.str)+1];
	strcpy(tmp.str,s1.str);
	strcat(tmp.str,s2.str);
	return tmp;
}
String & String::operator+=(const String &s) throw(bad_alloc){
	*this=*this+s;
	return *this;
}
//���ع�ϵ�����
bool operator<(const String &s1,const String s2){
	return strcmp(s1.str,s2.str)<0;
}
bool operator<=(const String &s1,const String s2){
	return strcmp(s1.str,s2.str)<=0;
}
bool operator>(const String &s1,const String s2){
	return strcmp(s1.str,s2.str)>0;
}
bool operator>=(const String &s1,const String s2){
	return strcmp(s1.str,s2.str)>=0;
}
bool operator==(const String &s1,const String s2){
	return strcmp(s1.str,s2.str)==0;
} 
bool operator!=(const String &s1,const String s2){
	return strcmp(s1.str,s2.str)!=0;
}
//���ط����������
char & String::operator[](int index) throw(int){
	if(index>strlen(str)) throw int(0);
	return str[index];
}
