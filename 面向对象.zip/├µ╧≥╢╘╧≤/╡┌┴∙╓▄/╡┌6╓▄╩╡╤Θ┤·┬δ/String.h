#ifndef String_H
#define String_H
#include<iostream>
using namespace std;
class String{
public:
	String(const char *s="") throw(bad_alloc);
	String(const String &s) throw(bad_alloc);
	virtual ~String();
	String & operator=(const String &s) throw(bad_alloc); 
	int length() const;
	const char * c_str();
	//����I/O����������� 
	friend ostream & operator<<(ostream &out,const String &s);
	friend istream & operator>>(istream &in,String &s) throw(bad_alloc);
	//����+��+=�����
	friend String operator+(const String &s1,const String s2) throw(bad_alloc);
	String & operator+=(const String &s) throw(bad_alloc);
	//���ع�ϵ�����
	friend bool operator<(const String &s1,const String s2);
	friend bool operator<=(const String &s1,const String s2);
	friend bool operator>(const String &s1,const String s2); 
	friend bool operator>=(const String &s1,const String s2); 
	friend bool operator==(const String &s1,const String s2); 
	friend bool operator!=(const String &s1,const String s2);  
	//���ط����������
	char & operator[](int index) throw(int);
private:
	char *str;
};
#endif

