#include<iostream>
#include"VeryLongInt.h"
using namespace std;
int main()
{
	VeryLongInt a("0"),b(1234),c=3456;
	cout<<a<<','<<b<<","<<c<<endl;
	a=b+c;cout<<a<<endl;
	a=c-b;cout<<a<<endl;
	a=a*b;cout<<a<<endl;
	a=b-c;cout<<a<<endl;
	a=a*b;cout<<a<<endl;
	a=a/b;cout<<a<<endl;
	a=b++;cout<<a<<","<<b<<endl;
	a=b--;cout<<a<<","<<b<<endl;
	a=++c;cout<<a<<","<<c<<endl;
	a=--c;cout<<a<<","<<c<<endl;
	if(b<c) cout<<"b<c"<<endl;
	if(c>b) cout<<"c>b"<<endl;
    if(c!=b) cout<<"c!=b"<<endl;
	if(a==c) cout<<"a==c"<<endl;
	cin>>a;
	cout<<a;
	return 0;
}
