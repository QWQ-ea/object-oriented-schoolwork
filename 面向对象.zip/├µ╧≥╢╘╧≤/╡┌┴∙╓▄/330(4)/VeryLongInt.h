#ifndef VERYLONGINT_H
#define VERYLONGINT_H
#include<iostream>
using namespace std;
class VeryLongInt
{ 
private:
int A[51];
public:
VeryLongInt(const char *shu);
VeryLongInt(int shu=0);
int & operator[](int index);
friend VeryLongInt operator+(VeryLongInt &a,VeryLongInt &b);
friend VeryLongInt operator-(VeryLongInt &a,VeryLongInt &b);
friend VeryLongInt operator*(VeryLongInt &a,VeryLongInt &b);
friend VeryLongInt operator/(VeryLongInt &a,VeryLongInt &b);
friend bool operator==(VeryLongInt &a,VeryLongInt &b);
friend bool operator!=(VeryLongInt &a,VeryLongInt &b);
friend bool operator>(VeryLongInt &a,VeryLongInt &b);
friend bool operator<(VeryLongInt &a,VeryLongInt &b);
friend bool operator>=(VeryLongInt &a,VeryLongInt &b);
friend bool operator<=(VeryLongInt &a,VeryLongInt &b);
VeryLongInt & operator=(const char *a);
VeryLongInt & operator=(int a);
VeryLongInt & operator=(const VeryLongInt &a);
VeryLongInt & operator+=(VeryLongInt &a);
VeryLongInt & operator-=(VeryLongInt &a);
VeryLongInt & operator*=(VeryLongInt &a);
VeryLongInt & operator/=(VeryLongInt &a);
VeryLongInt & operator++();
VeryLongInt & operator--();
VeryLongInt  operator++(int);
VeryLongInt  operator--(int);
friend ostream & operator<<(ostream &out,VeryLongInt &a);
friend istream & operator>>(istream &in,VeryLongInt &a);
friend int compare(VeryLongInt &a,VeryLongInt &b);
friend VeryLongInt & juedui(const VeryLongInt &a);
};
#endif
