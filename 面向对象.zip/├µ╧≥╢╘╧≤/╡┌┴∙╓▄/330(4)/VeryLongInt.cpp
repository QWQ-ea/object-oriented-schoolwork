#include<iostream>
#include"VeryLongInt.h"
using namespace std;
VeryLongInt::VeryLongInt(const char *shu)
{
*this=shu;
}
VeryLongInt::VeryLongInt(int shu)
{
*this=shu;
}
VeryLongInt & VeryLongInt::operator=(const char *a)
{
int i,j,k;
A[0]=0;
for(i=0;a[i]==' '||a[i]=='\t'||a[i]=='0';i++) ;
if(a[i]=='-') {A[0]=1;i++;}
else if(a[i]=='+') i++;
for(;a[i]==' '||a[i]=='\t'||a[i]=='0';i++) ;
for(j=i;a[j];j++) ;
for(k=1,j--;k<51&&j>=i;j--)
{
if(a[j]<='9'&&a[j]>='0') A[k++]=a[j]-'0';
}
for(;k<51;k++) A[k]=0;
return *this;
}
VeryLongInt & VeryLongInt::operator=(int a)
{int i;
A[0]=(a>=0)?0:1;	
for(i=1;i<51&&a>0;i++){
A[i]=a%10;
a/=10;
}
for(;i<51;i++) A[i]=0;
return *this;
}
int & VeryLongInt::operator[](int index)
{
	return A[index];
}
VeryLongInt &VeryLongInt::operator=(const VeryLongInt &a)
{
	for(int i=50;i>=0;i--) this->A[i]=a.A[i];
}
int compare(VeryLongInt &a,VeryLongInt &b)
{int i;
	for(i=50;a[i]==b[i]&&i>0;i--);
	if(a[i]>b[i]) return 1;
	if(a[i]<b[i]) return -1;
	if(i==0) return 0;
}
VeryLongInt & juedui(const VeryLongInt &a)
{VeryLongInt b=a;
b[0]=0;
return b;
}
VeryLongInt operator+(VeryLongInt &a,VeryLongInt &b)
{VeryLongInt c=0;
	switch (a[0]+b[0]) {
	case 0:
	for(int i=1;i<51;i++) 
	{
		c[i]=c[i]+a[i]+b[i];
		if(c[i]>=10&&i!=50) {c[i+1]++;c[i]-=10;} 
	}
		break;
	case 1:
	if(compare(a,b)==1)
	{
		for(int i=1;i<51;i++)
		{
			c[i]+=a[i]-b[i];
			if(c[i]<0) {c[i+1]--;c[i]+=10;}
		}
		if(a[0]==1) c[0]=1;
	}
	if(compare(a,b)==-1)
	{
		for(int i=1;i<51;i++)
		{
			c[i]+=b[i]-a[i];
			if(c[i]<0) {c[i+1]--;c[i]+=10;}
		}
		if(a[0]==0) c[0]=1;
	}
	if(compare(a,b)==0);
		break;
		default:
		for(int i=1;i<51;i++)
		{
			c[i]+=a[i]+b[i];
			if(c[i]>=10&&i!=50) {c[i+1]++;c[i]-=10;} 
		}
		c[0]=1;
			break;
	}
return c;
}
VeryLongInt operator-(VeryLongInt &a,VeryLongInt &b)
{VeryLongInt c=0;
	switch (a[0]+b[0]) {
	case 0:
if(compare(a,b)==1)
{
	for(int i=1;i<51;i++)
	{
		c[i]+=a[i]-b[i];
		if(c[i]<0) {c[i+1]--;c[i]+=10;}
	}
}
if(compare(a,b)==-1)
{
	for(int i=1;i<51;i++)
	{
		c[i]+=b[i]-a[i];
		if(c[i]<0) {c[i+1]--;c[i]+=10;}
	}
	c[0]=1;
}
if(compare(a,b)==0);
		break;
	case 1:
c=juedui(a)+juedui(b);
if(a[0]==1) c[0]=1;
		break;
		default:
		if(compare(a,b)==0);
		if(compare(a,b)==1)
		{
			c=juedui(a)-juedui(b);c[0]=1;
		}
		if(compare(a,b)==-1)
		{
			c=juedui(b)-juedui(a);
		}
			break;
	}
	return c;
}
VeryLongInt operator*(VeryLongInt &a,VeryLongInt &b)
{int n,k,m;VeryLongInt c=0;
	for(n=50;a[n]==0&&n>0;n--);
	for(m=50;b[m]==0&&m>0;m--);
	for(int i=1;i<=n;i++)
	{
		k=i;
		for(int j=1;j<=m;j++)
		{
			c[k]+=a[i]*b[j]%10;
			if(c[k]>9){c[k+1]++;c[k]-=10;}
			k++;
			if(k==51) break;
			c[k]+=a[i]*b[j]/10;
		}
	}
	if(a[0]!=b[0]) c[0]=1;
	return c;
}
VeryLongInt operator/(VeryLongInt &a,VeryLongInt &b)
{VeryLongInt c=0;int n,m,k;
if(compare(a,b)==-1) return c;
else if(compare(a,b)==0) {if(a[0]!=b[0]) c=-1;else if(a[0]==b[0]) c=1;return c;}
else if(compare(a,b)==1) {
	for(n=50;a[n]==0&&n>0;n--);
	for(m=50;b[m]==0&&m>0;m--);
if(a[n]>b[m]) k=n-m;
else if(a[n]<b[m]) k=n-m-1;
int i=1;
for(;k>0;k--) i*=10;
int t=0;

for(;i>0;i/=10){
VeryLongInt p(i),d=b;
while(compare(a,d)==1)
{
c+=p;
d=c*b;
}
c-=p;
}
return c;
}
}
VeryLongInt & VeryLongInt::operator+=(VeryLongInt &a)
{
	*this=*this+a;
	return *this;
}
VeryLongInt & VeryLongInt::operator-=(VeryLongInt &a)
{
	*this=*this-a;
	return *this;
}
VeryLongInt & VeryLongInt::operator*=(VeryLongInt &a)
{
	*this=*this*a;
	return *this;
}
VeryLongInt & VeryLongInt::operator/=(VeryLongInt &a)
{
	*this=*this/a;
	return *this;
}
VeryLongInt & VeryLongInt::operator++()
{VeryLongInt n=1;
	*this=*this+n;
	return *this;
}
VeryLongInt & VeryLongInt::operator--()
{VeryLongInt n=1;
	*this=*this-n;
	return *this;
}
VeryLongInt VeryLongInt::operator++(int)
{VeryLongInt n=1;
VeryLongInt a=*this;
*this=*this+n;
return a;
}
VeryLongInt VeryLongInt::operator--(int)
{VeryLongInt n=1;
	VeryLongInt a=*this;
	*this=*this-n;
	return a;
}
bool operator==(VeryLongInt &a,VeryLongInt &b)
{
	if(compare(a,b)==0&&a[0]==b[0]) return true;
	else return false;
}
bool operator!=(VeryLongInt &a,VeryLongInt &b)
{
	if(a[0]!=b[0]||compare(a,b)!=0) return true;
	else return false;
}
bool operator>(VeryLongInt &a,VeryLongInt &b)
{
	if(a[0]-b[0]==-1||compare(a,b)==1&&a[0]==0||compare(a,b)==-1&&a[0]==1) return true;
	else return false;
}
bool operator<(VeryLongInt &a,VeryLongInt &b)
{
	if(!(a>b)&&a!=b) return true;
	else return false;
}
bool operator>=(VeryLongInt &a,VeryLongInt &b)
{
	if(a>b||a==b) return true;
	else return false;
}
bool operator<=(VeryLongInt &a,VeryLongInt &b)
{
	if(a<b||a==b) return true;
	else return false;
}
ostream & operator<<(ostream &out,VeryLongInt &a)
{int n;
for(n=50;a[n]==0&&n>1;n--);
if(a[0]==0) out<<"+";else out<<"-";
for(;n>0;n--) out<<a[n];
return out;
}
istream & operator>>(istream &in,VeryLongInt &a)
{
char str[256];
in.getline(str,256);
a=str;
return in;
}
