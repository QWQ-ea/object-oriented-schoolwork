#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<string>
using namespace std;
class Employee
{
private:
string name,addr,zip;
public:
	Employee(string a="无名",string b="无家可归",string c="000000");
	Employee(char *a="无名",char *b="无家可归",char *c="000000");
	void ChangeName(string a);
	void Display() const;
};
#endif
