#include<iostream>
#include"Employee.h"
Employee::Employee(string a,string b,string c)
{   
	name=a;addr=b;zip=c;
}
Employee::Employee(char *a,char *b,char *c)
{string x(a),y(b),z(c);
name=x;addr=y;zip=z;	
}
void Employee::ChangeName(string a)
{
	name=a;
}
void Employee::Display() const
{
	std::cout<<name<<","<<addr<<","<<zip<<std::endl;
}
