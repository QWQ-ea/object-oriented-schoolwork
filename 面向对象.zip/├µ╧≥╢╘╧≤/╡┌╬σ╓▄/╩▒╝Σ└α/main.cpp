#include<iostream>
#include"time.h"
using namespace std;
int main()
{
	Time A,B(23,59,59),C(10861.0),X,Y,Z;
	int a,b,c;
	A.Display();B.Display();C.Display();
	A.SetTime(20,00,01);
	a=A.GetHour();b=A.GetMinute();c=A.GetSecond();
	cout<<"重置后的A:"<<a<<"时"<<b<<"分"<<c<<"秒"<<endl;
	X=B+int(2);Y=A-int(2);Z=A-B;
	X.Display();Y.Display();Z.Display();
	C=A++;C.Display();
	C=A--;C.Display();
	C=++B;C.Display();
	C=--B;C.Display();
	cout<<C;
	cin>>C;
	cout<<C;
	return 0;
}
