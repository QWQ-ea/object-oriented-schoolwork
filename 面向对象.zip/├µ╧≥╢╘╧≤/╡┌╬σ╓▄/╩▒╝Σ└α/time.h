#ifndef TIME_H
#define TIME_H
#include<iostream>
using namespace std;
class Time
{
private:
int Hour,Minute,Second;
public:
Time(int hour=0,int minute=0,int second=0);
Time(double Seconds);
int GetHour() const;
int GetMinute() const;
int GetSecond() const;
void SetTime(int hour,int minute,int second);	
void Display();
friend Time operator+(const Time &t,int n);	
friend Time operator-(const Time &t,int n);
Time operator-(const Time &t);
friend ostream & operator<<(ostream &out,const Time &t);
friend istream & operator>>(istream &in,Time &t);
Time &operator++();
Time &operator--();
Time operator++(int);
Time operator--(int);
};
#endif
