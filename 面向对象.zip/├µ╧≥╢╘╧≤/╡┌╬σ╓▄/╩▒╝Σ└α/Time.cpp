#include<iostream>
#include"time.h"
#include<stddef.h>
using namespace std;
Time::Time(int hour,int minute,int second):Hour(hour),Minute(minute),Second(second){}
Time::Time(double Seconds)
{int seconds=Seconds;
Hour=seconds/3600;
Minute=(seconds%3600)/60;
Second=seconds-Hour*3600-Minute*60;	
}
int Time::GetHour() const
{
	return Hour;
}
int Time::GetMinute() const
{
	return Minute;
}
int Time::GetSecond() const
{
	return Second;
}
void Time::SetTime(int hour,int minute,int second)
{
Hour=hour;
Minute=minute;
Second=second;
}
void Time::Display()
{
cout<<Hour<<"时"<<Minute<<"分"<<Second<<"秒"<<endl;	
}
Time Time::operator-(const Time &t)
{int hour,minute,second;Time A;
hour=this->Hour-t.Hour;
minute=this->Minute-t.Minute;
second=this->Second-t.Second;	
if(second<0) {A.Second=60+second;minute-=1;} else A.Second=second;
if(minute<0) {A.Minute=60+minute;hour-=1;}   else A.Minute=minute;
if(hour<0) {A.Hour=24+hour;} else A.Hour=hour;
return A;
}
ostream & operator<<(ostream &out,const Time &t)
{
out<<t.Hour<<":"<<t.Minute<<":"<<t.Second<<'\n';
return out;
}
istream & operator>>(istream &in,Time &t)
{char str[20];Time A;
if(in.getline(str,20,'\n'),str[0]=='\0') return in;A.Hour=atoi(str);
if(in.getline(str,20,'\n'),str[0]=='\0') return in;A.Minute=atoi(str);
if(in.getline(str,20,'\n'),str[0]=='\0') return in;A.Second=atoi(str);
t=A;
return in;
}
Time operator+(const Time &t,int n)
{
	int hour,minute,second;Time A=t;
	hour=n/3600+A.Hour;
	minute=(n%3600)/60+A.Minute;
	second=(n%3600)%60+A.Second;
	if(second>59) {A.Second=second-60;minute+=1;} else A.Second=second;
	if(minute>59) {A.Minute=minute-60;hour+=1;} else A.Minute=minute;
	if(hour>23) {A.Hour=hour-24;} else A.Hour=hour;
	return A;
}
Time operator-(const Time &t,int n)
{
	int hour,minute,second;Time A=t;
	hour=A.Hour-n/3600;
	minute=A.Minute-(n%3600)/60;
	second=A.Second-(n%3600)%60;
	if(second<0) {A.Second=60+second;minute-=1;} else A.Second=second;
	if(minute<0) {A.Minute=60+minute;hour-=1;}   else A.Minute=minute;
	if(hour<0) {A.Hour=24+hour;} else A.Hour=hour;
	return A;
}
Time & Time::operator++()
{
	*this=*this+int(1);
	return *this;
}
Time & Time::operator--()
{
    *this=*this-int(1);
	return *this;
}
Time Time::operator--(int)
{Time A=*this;
	*this=*this-int(1);
	return A;
}
Time Time::operator++(int)
{Time A=*this;
	*this=*this+int(1);
	return A;
}
