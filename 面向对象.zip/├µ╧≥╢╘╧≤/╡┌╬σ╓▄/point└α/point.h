#ifndef POINT_H
#define POINT_H
class point
{
private:
	double x,y;
public:
point(double a=0,double b=0);	
void Set(double a,double b);
friend double Distance(const point &a,const point &b);	
};
#endif
