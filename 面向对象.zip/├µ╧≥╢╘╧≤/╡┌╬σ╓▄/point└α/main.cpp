#include<iostream>
#include"point.h"
using namespace std;
int main(){
	point A,B(1,2);double x;
	x=Distance(A,B);
	cout<<"A与B的距离是"<<x<<endl;
	A.Set(2,-1);
	x=Distance(A,B);
	cout<<"A与B的距离是"<<x<<endl;
	return 0;
}
