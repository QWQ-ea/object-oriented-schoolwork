#include<iostream>
#include"point.h"
#include<cmath>
using namespace std;
point::point(double a,double b)
{
x=a;y=b;		
}
void point::Set(double a,double b)
{
	x=a;y=b;
}
double Distance(const point &a,const point &b)
{
double c=a.x-b.x,d=a.y-b.y,distance;	
	 if(c<0) c=-c;if(d<0) d=-d;
	 distance=sqrt(c*c+d*d);
	 return distance;
}
