#include<iostream>
#include"Date.h"
using namespace std;
int Date::days[12]={31,28,31,30,31,30,31,31,30,31,30,31};
Date::Date(int a,int b,int c) {
	year=a;month=b;day=c;
	if(year%4==0) days[1]=29;
	else days[1]=28;
}
void Date::dijitian() {
	num=0;
	for(int i=0;i<month-1;i++){
		num+=days[i];
	}
	num+=day;
}
int Date::Getnum() const
{
	return num;
}
void Date::Set(int a,int b,int c){
	year=a;month=b;day=c;
}
void Date::Show() const
{
	cout<<"对象的日期在当年为"<<num<<"天";
}

