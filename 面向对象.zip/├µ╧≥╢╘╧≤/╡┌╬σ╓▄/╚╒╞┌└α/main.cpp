#include<iostream>
#include"Date.h"
using namespace std;
int main(){
	Date A(2022,10,10),B;int a,b;
	A.dijitian();B.dijitian();
	a=A.Getnum();b=B.Getnum();
	cout<<"对象的日期在当年为"<<a<<"天"<<endl;
	cout<<"对象的日期在当年为"<<b<<"天"<<endl;
	B.Set(2020,3,1);
	B.dijitian();
	B.Show();
	return 0;
}
