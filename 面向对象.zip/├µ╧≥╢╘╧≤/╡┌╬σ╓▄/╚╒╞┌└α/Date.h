#ifndef DATE_H
#define DATE_H
class Date {
private:
	int year,month,day,num;
	static int days[12];
public:
    Date(int a=0,int b=0,int c=0);
    void dijitian();
    int Getnum() const;
    void Set(int a,int b,int c);
    void Show() const;
};
#endif
