#ifndef DATE_H
#define DATE_H
class Date{
private:
int a,b,c;	
public:
	Date(const int x=0,const int y=0,const int z=0);
	int Geta() const;
	int Getb() const;
	int Getc() const;
	void Nextdate() const;
	void settime(int x,int y,int z);
};
#endif
