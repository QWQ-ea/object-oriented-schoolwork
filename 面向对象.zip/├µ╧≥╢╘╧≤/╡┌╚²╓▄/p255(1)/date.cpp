#include<iostream>
#include"date.h"
using namespace std;
Date::Date(const int x,const int y,const int z){
a=x;b=y;c=z;
}
int Date::Geta() const
{
	return a;
}
int Date::Getb() const
{
	return b;
}
int Date::Getc() const
{
	return c;
}
void Date::Nextdate() const
{int m=a,n=b,r=c,x,y,z;
	switch (n) {
	case 1:
		z=(r==31)?1:r+1;
		break;
	case 2:
		z=(r==29&&m%4==0||r==28&&m%4!=0)?1:r+1;
		break;
	case 3:
		z=(r==31)?1:r+1;
		break;
	case 4:
		z=(r==30)?1:r+1;
		break;
	case 5:
		z=(r==31)?1:r+1;
		break;
	case 6:
		z=(r==30)?1:r+1;
		break;
	case 7:
		z=(r==31)?1:r+1;
		break;
	case 8:
		z=(r==31)?1:r+1;
		break;
	case 9:
		z=(r==30)?1:r+1;
		break;
	case 10:
		z=(r==31)?1:r+1;
		break;
	case 11:
		z=(r==30)?1:r+1;
		break;
		default:
			z=(r==31)?1:r+1;
			break;
	}
if(z==1){y=n+1;if(n==12){x=m+1;y=1;}}	
else {x=m;y=n;}
cout<<"本日期"<<m<<"."<<n<<"."<<r<<"的下一天日期为："
    <<x<<"."<<y<<"."<<z<<endl;
}
void Date::settime(int x,int y,int z){
	a=x;b=y;c=z;
}
