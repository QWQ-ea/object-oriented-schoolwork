#include<iostream>
#include"date.h"
using namespace std;
int main(){
	int x,y,z;
	Date a(2021,12,31),b;
	a.Nextdate();
    b.settime(2022,10,1);
	x=b.Geta();y=b.Getb();z=b.Getc();
	cout<<x<<"."<<y<<"."<<z<<endl;
	b.Nextdate();
	return 0;
}
