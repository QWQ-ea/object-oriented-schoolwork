#include<iostream>
#include"CSolver.h"
using namespace std;
int main(){
	int a,b,c,x1,x2,flag;
	CSolver m(1,-2,1),r(2,1,1),s(1,2,0),t(0,0,1),n;
	n.Set(0,1,0);
	a=n.GetA();b=n.GetB();c=n.GetC();x1=n.GetX1();x2=n.GetX2();flag=n.GetFlag();
	cout<<a<<","<<b<<","<<c<<","<<x1<<","<<x2<<","<<flag<<endl;
	n.ShowEquation();n.Solve();
	m.ShowEquation();m.Solve();
	s.ShowEquation();s.Solve();
	r.ShowEquation();r.Solve();
	t.ShowEquation();t.Solve();
	n.ShowSolution();
	m.ShowSolution();
	s.ShowSolution();
	r.ShowSolution();
	t.ShowSolution();
	return 0;
}
