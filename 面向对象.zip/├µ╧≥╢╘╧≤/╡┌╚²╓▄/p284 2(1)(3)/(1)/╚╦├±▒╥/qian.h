#ifndef QIAN_H
#define QIAN_H
namespace myspace
{
class RMB	
{
private:	
int yuan,jiao,fen;	
public:
RMB(int a=0,int b=0,int c=0);
RMB(double a);
Set(int a,int b,int c);
int Getyuan() const;
int Getjiao() const;
int Getfen() const;
void show() const;
};	
}
#endif
