#include<iostream>
#include"qian.h"
using namespace std;
int main(){
myspace::RMB x,y(1,2,3),z(1.23);
int a,b,c;
x.show();
x.Set(1,2,3);
a=x.Getyuan();b=x.Getjiao();c=x.Getfen();
cout<<a<<"元"<<b<<"角"<<c<<"分"<<endl;
y.show();z.show();
	return 0;
}
