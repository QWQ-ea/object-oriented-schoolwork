#include<iostream>
#include"qian.h"
myspace::RMB::RMB(int a,int b,int c)
{yuan=a;jiao=b;fen=c;}
myspace::RMB::RMB(double a)
{
yuan=a;
jiao=(a-yuan)*10;
fen=(a-yuan)*100-jiao*10;
std::cout<<fen<<std::endl;
}
myspace::RMB::Set(int a,int b,int c)
{yuan=a;jiao=b;fen=c;}
int myspace::RMB::Getyuan() const
{return yuan;}
int myspace::RMB::Getjiao() const
{return jiao;}
int myspace::RMB::Getfen() const
{return fen;}
void myspace::RMB::show() const
{std::cout<<yuan<<"元"<<jiao<<"角"<<fen<<"分"<<std::endl;}
