#include<iostream>
#include"Employee.h"
#include<cstring>
Employee::Employee(char *a,char *b,char *c)
{int x=strlen(a),y=strlen(b),z=strlen(c);
	strncpy(name,a,x);name[x]='\0';
	strncpy(addr,b,y);addr[y]='\0';
	strncpy(zip,c,z);name[z]='\0';
}
Employee::Employee():name("无名"),addr("无家可归"),zip("000000")
{ 
	return;
}
void Employee::ChangeName(char *a)
{int x=strlen(a);
strncpy(name,a,x);name[x]='\0';	
}
void Employee::Display() const
{
	std::cout<<name<<","<<addr<<","<<zip<<std::endl;
}
