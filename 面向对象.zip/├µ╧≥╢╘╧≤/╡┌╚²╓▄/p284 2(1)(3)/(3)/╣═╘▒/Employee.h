#ifndef EMPLOYEE_H
#define EMPLOYEE_H
class Employee
{
private:
	char name[20],addr[20],zip[20];
public:
	Employee(char *a="无名",char *b="无家可归",char *c="000000");
    Employee();
	void ChangeName(char *a);
	void Display() const;
};
#endif
